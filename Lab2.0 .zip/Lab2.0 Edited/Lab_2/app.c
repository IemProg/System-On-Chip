#include <io.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include "lepton/lepton.h"
#include "system.h"

int main(void) {
    // Hardware control structures
    lepton_dev lepton = lepton_inst((void *) LEPTON_0_BASE);

    // Initialize hardware
    lepton_init(&lepton);

    bool error = false;
    do {
      lepton_start_capture(&lepton);
      lepton_wait_until_eof(&lepton);
      error = lepton_error_check(&lepton);
    }while (error);

    // Save the adjusted (rescaled) buffer to a file.
    print("Done Capturing, Saving Image in '/mnt/host/output.pgm' \n");
    lepton_save_capture(&lepton, true, "/mnt/host/output.pgm");
    printf("Your image is written to host\n");

    return EXIT_SUCCESS;
}
